#!/usr/bin/env python3
"""Setu Stones — public crypto toolkit (KZG over BLS12-381).

This is the HONEST public primitive used by both the challenge distribution and the verifier.
It contains NO secrets (no trapdoor tau, no blueprint W, no blinding b) and NO solver.
Players load the public parameters with `load_params`, build their proof objects, and submit them.

  Com(f)    = [f(tau)]_1
  Open(f,z) = ([q(tau)]_1, y=f(z))   where q(X) = (f(X) - y)/(X - z)
  Verify    = e([1]_2, Com(f) - [y]_1) == e([tau]_2 - [z]_2, pi)

Field = scalar field r of BLS12-381. Polynomials are little-endian coefficient lists mod r.
"""
import hashlib, json
from py_ecc.optimized_bls12_381 import (
    G1, G2, curve_order, multiply, add, neg, pairing, normalize, is_inf, FQ, FQ2, Z1,
)

r = curve_order

# ------------------------------------------------------------------ field / polynomial helpers
def finv(a): return pow(a % r, r - 2, r)
def poly_eval(f, x):
    acc = 0
    for c in reversed(f): acc = (acc * x + c) % r
    return acc
def poly_add(a, b):
    out = [0] * max(len(a), len(b))
    for i, c in enumerate(a): out[i] = (out[i] + c) % r
    for i, c in enumerate(b): out[i] = (out[i] + c) % r
    return out
def poly_scale(a, s): return [(c * s) % r for c in a]
def poly_sub(a, b): return poly_add(a, poly_scale(b, r - 1))
def poly_mul(a, b):
    out = [0] * (len(a) + len(b) - 1)
    for i, ai in enumerate(a):
        if ai:
            for j, bj in enumerate(b): out[i + j] = (out[i + j] + ai * bj) % r
    return out
def poly_divroot(f, z):
    """exact division f(X)/(X-z) assuming f(z)=0 (synthetic division)."""
    q = [0] * (len(f) - 1); carry = 0
    for i in range(len(f) - 1, 0, -1):
        q[i - 1] = (f[i] + carry) % r
        carry = (q[i - 1] * z) % r
    return q
def lagrange_interp(xs, ys):
    res = [0]
    for i in range(len(xs)):
        num = [1]; den = 1
        for j in range(len(xs)):
            if j == i: continue
            num = poly_mul(num, [(-xs[j]) % r, 1]); den = (den * (xs[i] - xs[j])) % r
        res = poly_add(res, poly_scale(num, (ys[i] * finv(den)) % r))
    return res
def vanishing(domain):
    Z = [1]
    for h in domain: Z = poly_mul(Z, [(-h) % r, 1])
    return Z

# ------------------------------------------------------------------ group helpers
def g1(s): return multiply(G1, s % r)
def g2(s): return multiply(G2, s % r)
def g1_lincomb(points, scalars):
    acc = Z1
    for P, s in zip(points, scalars):
        if s % r: acc = add(acc, multiply(P, s % r))
    return acc

# ------------------------------------------------------------------ KZG (needs public SRS only)
def commit(params, f):
    return g1_lincomb(params["g1_powers"][:len(f)], f)
def open_at(params, f, z):
    y = poly_eval(f, z)
    fshift = f[:]; fshift[0] = (fshift[0] - y) % r
    return y, commit(params, poly_divroot(fshift, z))
def verify(params, C, z, y, pi):
    lhs = pairing(params["g2_1"], add(C, neg(g1(y))))
    rhs = pairing(add(params["g2_tau"], neg(g2(z))), pi)
    return lhs == rhs

# ------------------------------------------------------------------ Fiat-Shamir transcript (the protocol's)
def ser_g1(P):
    if is_inf(P): return ["inf", "inf"]
    x, y = normalize(P); return [str(int(x)), str(int(y))]
def deser_g1(t):
    if t[0] == "inf": return Z1
    return (FQ(int(t[0])), FQ(int(t[1])), FQ.one())
def ser_g2(P):
    x, y = normalize(P)
    return [[str(int(x.coeffs[0])), str(int(x.coeffs[1]))], [str(int(y.coeffs[0])), str(int(y.coeffs[1]))]]
def deser_g2(t):
    return (FQ2([int(t[0][0]), int(t[0][1])]), FQ2([int(t[1][0]), int(t[1][1])]), FQ2.one())

def _ser_point_for_hash(P):
    x, y = normalize(P); return (int(x), int(y))
def fs_hash(*chunks):
    h = hashlib.sha256()
    for c in chunks:
        if isinstance(c, int): h.update(c.to_bytes(32, "big"))
        elif isinstance(c, bytes): h.update(c)
        else: h.update(repr(c).encode())
    return int.from_bytes(h.digest(), "big") % r
def transcript_zeta(C_W, PUB_S):
    """the protocol's Fiat-Shamir challenge point, derived from the transcript (see the challenge README)."""
    return fs_hash(_ser_point_for_hash(C_W), tuple(PUB_S))

# ------------------------------------------------------------------ parameter (de)serialization
def params_to_json(params):
    return {
        "degree": params["degree"],
        "g1_powers": [ser_g1(P) for P in params["g1_powers"]],
        "g2_1": ser_g2(params["g2_1"]),
        "g2_tau": ser_g2(params["g2_tau"]),
    }
def load_params(path):
    with open(path) as f: j = json.load(f)
    return {
        "degree": j["degree"],
        "g1_powers": [deser_g1(t) for t in j["g1_powers"]],
        "g2_1": deser_g2(j["g2_1"]),
        "g2_tau": deser_g2(j["g2_tau"]),
    }
