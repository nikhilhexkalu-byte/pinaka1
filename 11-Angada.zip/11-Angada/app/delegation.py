"""delegation-authority — issues signed delegations. A delegation authorises a delegate to act on a
DOCUMENT (by identity). Only a document's owner may have the authority delegate its handling."""
from fastapi import APIRouter, Depends, HTTPException, Body
from .deps import ctx
from .store import new_id

router = APIRouter(prefix="/delegation", tags=["delegation-authority"])

@router.post("/delegations")
def issue(doc_id: str = Body(...), delegate: str = Body(...), permission: str = Body("dispatch"), c=Depends(ctx)):
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc:
        raise HTTPException(404, "no such document")
    if permission not in ("dispatch", "edit"):
        raise HTTPException(400, "unknown permission")
    # authority to delegate a document's handling belongs to its owner.
    if doc["owner"] != user:
        raise HTTPException(403, "only the document owner may delegate its handling")
    d = {"id": new_id("deleg"), "doc_id": doc_id, "delegator": user, "delegate": delegate,
         "permission": permission}
    d["sig"] = s.sign("delegation", d["doc_id"], d["delegate"], d["permission"])
    s.delegations[d["id"]] = d
    return {"delegation_id": d["id"], "doc_id": doc_id, "delegate": delegate,
            "permission": permission, "sig": d["sig"]}

@router.get("/delegations")
def mine(c=Depends(ctx)):
    s, user = c
    return [d for d in s.delegations.values() if d["delegate"] == user or d["delegator"] == user]
