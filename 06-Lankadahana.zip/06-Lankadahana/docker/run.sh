#!/bin/sh
# Plain local runner (no Docker): serve the daemon on TCP 1337 with a practice flag.
# Prints the same connect banner as the real target (via serve.sh).
export PINAKA_FLAG="${PINAKA_FLAG:-PINAKA{local_practice__now_build_it_for_the_real_target}}"
export LANKA_BIN="./lanka-dahan"
exec socat -T120 TCP-LISTEN:1337,reuseaddr,fork EXEC:./serve.sh
