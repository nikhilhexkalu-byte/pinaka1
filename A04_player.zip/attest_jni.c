#include <jni.h>
#include <stdint.h>
#include <string.h>

void native_mix(uint32_t *px, uint32_t *py, const uint32_t *rk);

extern void fsvm_attest(const uint8_t *buf, int len, const uint8_t key[16], uint8_t out[16]);

JNIEXPORT jbyteArray JNICALL
Java_com_pinaka_ashram_Attestation_nativeAttest(JNIEnv *env, jobject self, jbyteArray inputBuf) {
    jsize n = (*env)->GetArrayLength(env, inputBuf);
    jbyte *buf = (*env)->GetByteArrayElements(env, inputBuf, NULL);
    uint8_t key[16];
    warden_key(key);
    uint8_t out[16];
    fsvm_attest((const uint8_t *)buf, (int)n, key, out);
    (*env)->ReleaseByteArrayElements(env, inputBuf, buf, JNI_ABORT);
    jbyteArray r = (*env)->NewByteArray(env, 16);
    (*env)->SetByteArrayRegion(env, r, 0, 16, (const jbyte *)out);
    return r;
}
