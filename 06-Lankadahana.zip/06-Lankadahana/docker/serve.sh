#!/bin/sh
# per-connection: one-line banner (identical to production), then hand off to the daemon.
printf '%s\n' 'Lanka Dahan. Five gates stand. Open them in order.'
exec "${LANKA_BIN:-./lanka-dahan}"
