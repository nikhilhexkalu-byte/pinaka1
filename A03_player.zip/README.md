# A03 — Vishvamitra: The Broken Invocation

*In Siddhashrama the sage Vishvamitra keeps the Celestial Armory, where every weapon answers
only to a sealed invocation — a proof that the one who chants it is bound to that weapon's boon.
The sage has already been granted the lesser boons, **Bala** and **Atibala**, and his sealed
invocation for them is a matter of public record. The supreme astra, the **Brahmastra**, answers
to a boon only the Devas hold. Yet an invocation is only as strong as the syllable that binds
it — and this one was chanted with a syllable left unfastened.*

## Target

A single HTTP/JSON service — the **Celestial Armory validator**. Connection details for your
instance are provided by the platform.

Public endpoints:

| Method / path | What it returns |
|---|---|
| `GET /armory/params` | Group parameters (`p, q, g, h`), the public elevation offset `d`, and the invocation's binding rule (Fiat–Shamir challenge). |
| `GET /armory/registry` | The weapon registry (each weapon's **boon tuple** `(A, B)`), Vishvamitra's **leaked grant-proof**, and the **forbidden target**. |
| `POST /armory/invoke` | Body `{"weapon": <name>, "proof": {"t1": <int>, "t2": <int>, "s": <int>}}`. The armory recomputes the challenge and verifies your proof against that weapon's boon tuple. |

The public invocation primitive (`pinaka_invocation.py`) and the instance files
(`params.json`, `instance.json`) ship alongside this brief. Read them: the protocol is fully
specified there.

## The protocol

A **boon tuple** `(A, B)` is valid iff there exists a single witness `w` with `A = g^w (mod p)`
and `B = h^w (mod p)`. A grant-proof `(t1, t2, s)` is accepted for `(A, B)` iff

```
g^s ≡ t1 · A^c   (mod p)      and      h^s ≡ t2 · B^c   (mod p),
```

where `c` is the Fiat–Shamir challenge computed by `fiat_shamir_challenge(...)`.

## Goal

Make the armory grant you the **forbidden weapon** (`brahmastra`) by presenting a **valid
grant-proof for its boon tuple** — without any signing key, secret exponent, or witness. You
hold only what is public: the parameters, the registry, and Vishvamitra's leaked grant for the
lesser boons.

Submit your forged proof to `POST /armory/invoke` with `"weapon": "brahmastra"`. The armory
validates server-side and returns the sealed proclamation (the flag) only when a genuinely
verifying proof for the forbidden boon tuple is presented. There is no flag in any file.
