#!/usr/bin/env bash
# Local runner for the Siddhashrama Vigil daemon.
#
#   ./run.sh                 talk to the daemon directly on this terminal (stdin/stdout)
#   ./run.sh --tcp [PORT]    expose it as a local TCP service (needs socat), default 8060
#
# The real challenge instance is hosted; set PINAKA_FLAG only for local practice.
set -eu
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="$HERE/vigil"
: "${PINAKA_FLAG:=PINAKA{local-practice-A06-set-PINAKA_FLAG-in-env}}"
export PINAKA_FLAG

if [ "${1:-}" = "--tcp" ]; then
  PORT="${2:-8060}"
  echo "[run] serving vigil on tcp/$PORT (socat, one process per connection)"
  exec socat TCP-LISTEN:"$PORT",reuseaddr,fork EXEC:"$BIN",stderr
else
  echo "[run] talking to vigil over stdin/stdout — type HELP for commands, QUIT to leave."
  exec "$BIN"
fi
