"""Shared request context: resolve the per-session sandbox and the acting user (always the envoy)."""
from fastapi import Header, HTTPException
from .store import get_session

def ctx(x_session: str = Header(None), authorization: str = Header(None)):
    s = get_session(x_session)
    if not s:
        raise HTTPException(401, "unknown or missing session (create one at POST /portal/session)")
    token = (authorization or "").removeprefix("Bearer ").strip()
    user = s.user_of(token)
    if not user:
        raise HTTPException(401, "bad credential")
    return s, user

def can_edit(s, user, doc):
    if doc["owner"] == user:
        return True
    for d in s.delegations.values():
        if d["doc_id"] == doc["id"] and d["delegate"] == user and d["permission"] in ("edit", "dispatch"):
            return True
    return False
