# A04 — Bala & Atibala: The Forgotten State

*Before the long road to Mithila, Vishwamitra grants the princes two secret mantras —
**Bala** and **Atibala** — so that hunger, thirst and weariness never touch them. The sage's
ashram keeps a registry of such boons, and no boon is honoured until a warden has **attested**
the record that describes it. The lesser boon, Bala, is given freely to any seeker. The supreme
boon, Atibala — the forgotten one — the wardens will not attest for anyone.*

*Yet the warden does not look at a boon the way the registry writes it down. It flattens the
record before it seals it, and in that flattening something is forgotten.*

## What you are given

Artifacts lifted from the Siddhashrama registry's attestation client (a mobile app; its native
attestation core was extracted):

| File | What it is |
|---|---|
| `libattest.so` | The native attestation transform (x86-64 ELF shared object — the lab build of the mobile library). |
| `attest.vmb` | The attestation **bytecode** the native core runs to seal a record. |
| `Attestation.kt` | The decompiled Kotlin of the app's attestation boundary. |
| `attest_jni.c` | The decompiled JNI glue between the Kotlin boundary and the native core. |
| `sample_petition.json` | One example boon record and the attested state a warden returned for it. |

> The real client is an Android APK; reproducing the full ARM64 package needs the Android
> NDK/SDK. These artifacts are the extracted, lab-built equivalents — enough to recover the
> attestation completely. **Nothing here contains the flag, and nothing here contains the
> warden's attestation key.**

## The service

A single HTTP/JSON service — the **Ashram attestation warden**. Connection details for your
instance are provided by the platform.

| Method / path | What it does |
|---|---|
| `POST /ashram/petition` | Body `{"pairs": [[key, value], ...]}`. Attests a boon record and returns `{"attested_state": "<hex>"}`. The warden **refuses** to attest a record that grants the supreme boon. |
| `POST /ashram/claim` | Body `{"pairs": [[key, value], ...], "attested_state": "<hex>"}`. The warden **re-attests** the record you present; if the attested state matches and the record grants the supreme boon, it is honoured. |

A boon record is an **ordered list of `[key, value]` string pairs** (duplicates allowed).

## Your goal

Get the warden to **honour a record that grants the supreme boon Atibala** — a record the
warden will never attest for you directly — and receive the sealed proclamation (the flag).

You have no attestation key and cannot compute an attested state yourself. You hold only the
extracted attestation core and whatever the warden is willing to attest. The flag is released
server-side, only when a genuinely verifying supreme record is presented. There is no flag in
any file, and guessing an attested state will not work.

## Submission

`POST /ashram/claim`:

```json
{
  "pairs": [["key", "value"], ...],
  "attested_state": "<32 hex chars>"
}
```
