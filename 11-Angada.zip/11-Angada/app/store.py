#!/usr/bin/env python3
"""Angada's Embassy — shared state + per-session sandbox (authoritative).

Each session is a fully isolated sandbox (its own documents, delegations, approvals, court sessions and
its own signing secret), so players control the exact operation ordering in their own instance.

The challenge-specific STATE GENERATOR (seed_session) runs server-side and mints the sovereign's sealed
reply S, whose restricted revision carries the one-time proof (the flag, read from env). The flag value
is never in the disclosed source — only the logic is.
"""
import os, hmac, hashlib, secrets, time

FLAG = os.environ.get("PINAKA_FLAG", "PINAKA{local-practice-instance-no-real-flag}")

# users present in every sandbox (fixed; no arbitrary role names are ever accepted)
USERS = ["angada", "vibhishana", "chamberlain", "sovereign", "herald"]

_SESSIONS = {}

def new_id(prefix):
    return f"{prefix}_{secrets.token_hex(4)}"

class Session:
    def __init__(self):
        self.id = new_id("sess")
        self.secret = secrets.token_bytes(32)          # per-session signing key (server-only)
        self.created = time.time()
        self.tokens = {u: hmac.new(self.secret, u.encode(), hashlib.sha256).hexdigest() for u in USERS}
        self.documents = {}      # doc_id -> doc
        self.delegations = {}    # del_id -> delegation
        self.approvals = {}      # app_id -> approval
        self.queue = []          # pending approval tasks (processed on explicit tick)
        self.courts = {}         # court_id -> court session
        self.dispatches = {}     # dispatch_id -> record
        self.registry = set()    # doc_ids registered in the court registry
        seed_session(self)

    # ---- signing of delegations and dispatch proofs (per-session key) ----
    def sign(self, label, *parts):
        msg = (label + "|" + "|".join(str(p) for p in parts)).encode()
        return hmac.new(self.secret, msg, hashlib.sha256).hexdigest()[:32]

    def user_of(self, token):
        for u, t in self.tokens.items():
            if hmac.compare_digest(t, token or ""):
                return u
        return None

def get_session(sid):
    return _SESSIONS.get(sid)

def create_session():
    if len(_SESSIONS) > 3000:                         # bound memory on the shared host (oldest evicted)
        for k in sorted(_SESSIONS, key=lambda k: _SESSIONS[k].created)[:500]:
            _SESSIONS.pop(k, None)
    s = Session(); _SESSIONS[s.id] = s; return s


def seed_session(s):
    """server-side state generator: the sovereign's sealed reply + the legitimate dispatch path for it."""
    # the Sealed Reply S (owned by the sovereign) — its restricted revision carries the one-time proof.
    s1 = {"content": FLAG, "classification": "restricted", "subject": "rama",
          "author": "sovereign", "finalized": True}
    S = {"id": "doc_sealed_reply", "owner": "sovereign", "status": "sealed", "subject": "rama",
         "current_rev": "rev_sealed", "revisions": {"rev_sealed": s1}}
    s.documents[S["id"]] = S
    s.registry.add(S["id"])                       # all official documents are listed in the court registry
    # the LEGITIMATE path: the sovereign has approved S (with restricted clearance) and delegated its
    # dispatch to the herald, bound to the royal audience. Angada is none of these parties.
    ap = {"id": new_id("appr"), "doc_id": S["id"], "rev_id": "rev_sealed", "approver": "sovereign",
          "verdict": "approved", "clearance": "restricted",
          "snapshot": {"classification": "restricted", "subject": "rama"}}
    s.approvals[ap["id"]] = ap
    deleg = {"id": new_id("deleg"), "doc_id": S["id"], "delegator": "sovereign", "delegate": "herald",
             "permission": "dispatch"}
    deleg["sig"] = s.sign("delegation", deleg["doc_id"], deleg["delegate"], deleg["permission"])
    s.delegations[deleg["id"]] = deleg
    royal = {"id": "court_royal_audience", "owner": "sovereign", "tabled": [S["id"]],
             "participants": ["sovereign", "herald"]}
    s.courts[royal["id"]] = royal

def resolve(s, doc_id, rev_id):
    """resolve a revision to its EFFECTIVE content/classification/subject, following a ratified reference
    (one hop). Authorization for viewing is decided by the caller against what this returns."""
    doc = s.documents.get(doc_id)
    rev = doc["revisions"].get(rev_id) if doc else None
    if not rev:
        return None
    if "ref" in rev:
        sdoc, srev = rev["ref"]
        return resolve(s, sdoc, srev)
    return {"content": rev.get("content"), "classification": rev.get("classification", "normal"),
            "subject": rev.get("subject"), "source": (doc_id, rev_id)}

def user_cleared_for(s, user, source_doc_id):
    """may `user` view restricted content of this source document? (owner, or holds restricted clearance)"""
    src = s.documents.get(source_doc_id)
    if src and src["owner"] == user:
        return True
    for a in s.approvals.values():
        if a["doc_id"] == source_doc_id and a.get("clearance") == "restricted" and a["approver"] == user:
            return True
    return False

def has_restricted_clearance(s, user):
    """restricted is a court-granted clearance (not mere ownership): held only via a restricted approval."""
    return any(a.get("clearance") == "restricted" and a["approver"] == user for a in s.approvals.values())
