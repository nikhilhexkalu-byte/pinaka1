# A06 — Siddhashrama: The Unbroken Vigil

*Vishwamitra brings Rama and Lakshmana to Siddhashrama, where the great sacrificial
rite — the yajna — must burn without interruption for days and nights. The rakshasas
Maricha and Subahu wait to defile it with blood and corruption the instant the watch
falters. So the sages raised a tireless guardian: an asynchronous **Vigil**, a defense
daemon that arms protective **wards** around the altar, hands each in turn to its
night-watch, retires the spent ones, sweeps away their ashes, and — without ever
breaking the watch — **renews a celestial guardian** to hold the sacred ground.*

*The Vigil has never once fallen. Its keepers call it unbroken. But an unbroken watch
is not the same as a flawless one. Somewhere in how the Vigil hands a ward from the
day-keeper's hand to the night-watch's, and in how it later reclaims what it believes
no one still holds, there is a seam. Find the seam, and you may stand where only the
celestial guardian is permitted to stand — and complete the rite's own **proof**.*

## What you are given

| File | What it is |
|---|---|
| `vigil` | The Vigil daemon — a stripped native binary. It speaks a simple line-based command protocol over stdin/stdout. |
| `run.sh` | A convenience runner: talk to the daemon directly, or (with `socat`) expose it as a local TCP service. |

No source, no symbols, no schema are provided. Reverse the binary.

## Talking to the Vigil

```
./run.sh              # interactive, on this terminal
./run.sh --tcp 8060   # serve locally over TCP (needs socat)
```

Send `HELP` to see the command vocabulary. The daemon manages ward objects inside a
fixed arena, mints you a **handle** for each ward you arm, and lets you inscribe and
read back a ward's contents, hand wards to its background watch, retire them, and ask
the watch to sweep and to renew its guardian. One command — the rite's **proof** — is
restricted: the Vigil will complete it only for a true celestial guardian, something
you are never given the means to create.

## Your goal

Reverse the Vigil's ownership rules and its arena, find the object-lifetime seam in how
the background watch reclaims and renews, and turn it into a reliable memory primitive.
Use that primitive to stand in a guardian's place and make the daemon complete its
restricted **proof** operation. On success the Vigil speaks the flag for your instance.

The flaw is fully deterministic — there is no race to win and no luck involved. A
correct understanding of who owns what, and when, is enough to reproduce it every time.

> The daemon will happily recite tempting "sigils" if you ask its oracle. None of them
> is the flag. The real flag is spoken only by the completed proof, and only on the
> hosted instance. There is exactly one way to earn it.
