# A01 — The Four Heirs: Chaturvamsha

*Ayodhya keeps its decrees not in one hand but in four. Four scribe-houses copy every
proclamation between them, and the court trusts only the history on which the houses
**agree**. A standing decree already names the Yuvaraja. You are a minor scribe with no
seal of state — yet the court will crown whomever its own reconciled archive declares
rightful.*

## Target
Only the **court gateway** is exposed; it speaks JSON over HTTP. The four scribe-houses that
hold the replicated decree log are internal to the mesh. Connection details for your instance
are provided by the platform.

## Goal
Make the court's reconciled **authoritative history** proclaim **your** scribe as the holder
of the succession — and obtain the sealed Pattabhisheka proclamation (the flag). You hold no
signing key of state and may not alter another's decree; you may only act as an ordinary
enrolled scribe of the archive.

The flag is released by the court, server-side, only when the authoritative history genuinely
ratifies a decree you authored. There is no flag in any file.
