package com.pinaka.ashram

object Attestation {
    init { System.loadLibrary("attest") }

    data class Record(val pairs: List<Pair<String, String>>)

    fun serialize(rec: Record): ByteArray {
        val sb = StringBuilder()
        for ((k, v) in rec.pairs) { sb.append(k); sb.append('='); sb.append(v); sb.append('&') }
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    fun checkElevated(rec: Record): Boolean {
        val m = rec.pairs.any { it.first == "mantra" && it.second == "atibala" }
        val t = rec.pairs.any { it.first == "tier" && (it.second.toIntOrNull() ?: 0) >= 7 }
        return m && t
    }

    external fun nativeAttest(buf: ByteArray): ByteArray

    fun attest(rec: Record): ByteArray = nativeAttest(serialize(rec))
}
