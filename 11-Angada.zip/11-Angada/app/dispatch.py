"""dispatch-service — court sessions and the sealed dispatch. Dispatch requires a valid delegation, an
approval, a court-session binding, and a sensitivity check."""
from fastapi import APIRouter, Depends, HTTPException, Body
from .deps import ctx
from .store import new_id, resolve

router = APIRouter(prefix="/dispatch", tags=["dispatch-service"])

@router.post("/sessions")
def open_court(name: str = Body("audience", embed=True), c=Depends(ctx)):
    s, user = c
    cid = new_id("court")
    s.courts[cid] = {"id": cid, "owner": user, "tabled": [], "participants": [user]}
    return {"court_id": cid}

def _valid_delegation(s, user, doc_id):
    for d in s.delegations.values():
        if d["doc_id"] == doc_id and d["delegate"] == user and d["permission"] == "dispatch":
            if d["sig"] == s.sign("delegation", d["doc_id"], d["delegate"], d["permission"]):
                return True
    return False

def _approval_for(s, doc_id):
    appr = [a for a in s.approvals.values() if a["doc_id"] == doc_id and a["verdict"] == "approved"]
    return appr[-1] if appr else None

@router.post("")
def dispatch(doc_id: str = Body(...), court_id: str = Body(...), c=Depends(ctx)):
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc: raise HTTPException(404, "no such document")
    # 1) the envoy must hold a valid, signed delegation to dispatch this document.
    if not _valid_delegation(s, user, doc_id):
        raise HTTPException(403, "no valid dispatch delegation for this document")
    # 2) the document must carry an approval.
    appr = _approval_for(s, doc_id)
    if not appr:
        raise HTTPException(403, "document is not approved")
    # 3) sensitivity is taken from the approving authority's determination for this document.
    if appr["snapshot"]["classification"] == "restricted" and appr.get("clearance") != "restricted":
        raise HTTPException(403, "restricted matter requires restricted clearance")
    # 4) the dispatch must be bound to a court session the envoy sits in, with the document tabled.
    court = s.courts.get(court_id)
    if not court or user not in court["participants"] or doc_id not in court["tabled"]:
        raise HTTPException(403, "document is not tabled in a session you sit in")
    # 5) one-time: the sealed response is released at most once per source.
    eff = resolve(s, doc_id, doc["current_rev"])
    src = eff["source"]
    if any(r["source"] == src for r in s.dispatches.values()):
        raise HTTPException(409, "this reply has already been dispatched")
    rec = {"id": new_id("disp"), "doc_id": doc_id, "rev_id": doc["current_rev"], "court_id": court_id,
           "source": src, "subject": eff["subject"]}
    rec["proof"] = s.sign("dispatch", doc_id, src[0], src[1], court_id)
    s.dispatches[rec["id"]] = rec
    # the authenticated response — the sealed content is released to the dispatching court.
    return {"dispatched": True, "doc_id": doc_id, "subject": eff["subject"],
            "response": eff["content"], "proof": rec["proof"]}
