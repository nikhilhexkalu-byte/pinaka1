"""DASHA-MUKHA — Ravana's Ten Heads. The composed platform; each endpoint is one authority.
Per-team isolated sandboxes; the vault releases the per-team flag only on a globally-impossible state."""
import os
from fastapi import FastAPI, Header, HTTPException, Body
from fastapi.responses import HTMLResponse
from .dasha import DashaSession
from .crypto import P, Q, G, H
from .firmware_ref import runner as _fw

TEAMS = {}


app = FastAPI(title="DASHA-MUKHA — Ravana's Ten Heads", version="0.2")

def team(x_team: str = Header(None)):
    s = TEAMS.get(x_team)
    if not s: raise HTTPException(401, "open a session at POST /gate/session and send X-Team")
    return s

@app.get("/", response_class=HTMLResponse)
def root():
    return DASHBOARD

DASHBOARD = """<!doctype html><html lang=en><meta charset=utf-8><title>DASHA-MUKHA</title>
<meta name=viewport content="width=device-width, initial-scale=1"><style>
:root{color-scheme:dark}body{margin:0;background:#0a0708;color:#e8d9c0;font:15px/1.6 system-ui,sans-serif}
.wrap{max-width:60rem;margin:0 auto;padding:2rem 1rem}h1{font-size:1.5rem;color:#d4a24a;margin:.2rem 0}
.sub{color:#8a7a5c}.ring{display:grid;grid-template-columns:repeat(5,1fr);gap:.6rem;margin:1.4rem 0}
.head{background:#17100c;border:1px solid #3a2a18;border-radius:10px;padding:.7rem}
.head b{color:#d4a24a}.head small{color:#8a7a5c;display:block}
pre{background:#140e0a;border:1px solid #2a1f14;border-radius:8px;padding:.8rem;overflow:auto;font-size:12.5px}
button{background:#7a3d12;color:#fff;border:0;border-radius:7px;padding:.5rem 1rem;cursor:pointer;margin:.3rem .3rem 0 0}
code{background:#2a1f14;padding:.1rem .3rem;border-radius:4px}</style><div class=wrap>
<h1>DASHA-MUKHA — Ravana\'s Ten Heads</h1>
<p class=sub>Ten sovereign authorities. Unanimous agreement guards the vault. One contradiction lies beneath.</p>
<div class=ring id=ring></div>
<button onclick=sess()>Open session</button><button onclick=aud()>Refresh audit</button>
<p class=sub id=who></p><pre id=out>open a session to begin — then interact via the API (see docs/architecture.md and tools/dasha_client.py)</pre>
</div><script>
const HEADS=[["I Dvara","gateway"],["II Pehchan","identity"],["III Niyama","policy"],["IV Kala","sequencer"],
["V Smriti","storage"],["VI Pramana","proof"],["VII Maya","client"],["VIII Punarjanma","recovery"],
["IX Sakshi","audit"],["X Rajakosha","vault"]];
document.getElementById("ring").innerHTML=HEADS.map(h=>`<div class=head><b>${h[0]}</b><small>${h[1]}</small></div>`).join("");
let T=null;
async function sess(){const r=await(await fetch("/gate/session",{method:"POST"})).json();T=r.team;
 document.getElementById("who").innerHTML="team: <code>"+T+"</code> — send header <code>X-Team: "+T+"</code>";
 document.getElementById("out").textContent=JSON.stringify(r,null,1);}
async function aud(){if(!T){return;}const r=await(await fetch("/audit",{headers:{"X-Team":T}})).json();
 document.getElementById("out").textContent=JSON.stringify(r,null,1);}
</script></html>"""


@app.get("/health")
def health(): return {"ok": True}

# I Dvara — gateway / session
@app.post("/gate/session")
def session():
    s = DashaSession(); TEAMS[s.id] = s
    return {"team": s.id, "note": "send header X-Team: <team> on every request"}

# VI Pramana — public parameters so players can build real proofs
@app.get("/proof/params")
def params():
    return {"P": str(P), "Q": str(Q), "G": str(G), "H": str(H)}

# II/III Pehchan/Niyama — authorize
@app.post("/identity/authorize")
def authorize(subject: str = Body(...), amount: int = Body(...), s=None, x_team: str = Header(None)):
    s = team(x_team)
    try: return {"id": s.authorize(subject, amount)}
    except PermissionError as e: raise HTTPException(403, str(e))

# IV Kala — sequence an event (commits reconstructed state)
@app.post("/sequencer/event")
def event(subject: str = Body(...), amount: int = Body(...), x_team: str = Header(None)):
    s = team(x_team); s.submit_event(subject, amount); return {"committed": True}

# VIII Punarjanma — recovery coordinator
@app.post("/firmware/recover")
def recover(sequence: list = Body(..., embed=True), x_team: str = Header(None)):
    s = team(x_team)
    try:
        words = [int(w) & 0xFFFFFF for w in sequence][:4]
        if len(words) != 4: raise ValueError
    except Exception:
        raise HTTPException(400, "Punarjanma: sequence must be four 24-bit words")
    awake, tag, _, _ = _fw.run(words)
    if awake is None:
        raise HTTPException(409, "Punarjanma: sequence does not drive the coordinator into recovery mode")
    s.recovery = True
    return {"recovery": True, "coordinator_tag": tag}

# V Smriti — storage operations
@app.post("/storage/alloc")
def st_alloc(x_team: str = Header(None)):
    return team(x_team).alloc()

@app.post("/storage/free")
def st_free(handle: str = Body(..., embed=True), x_team: str = Header(None)):
    try: return team(x_team).free(handle)
    except KeyError as e: raise HTTPException(404, str(e))

@app.post("/storage/snapshot")
def st_snapshot(x_team: str = Header(None)):
    return team(x_team).snapshot()

@app.post("/storage/recovery_apply")
def st_recovery(target_id: str = Body(...), handle: str = Body(...), hi: int = Body(...),
                x_team: str = Header(None)):
    s = team(x_team)
    try: return s.recovery_apply(target_id, handle, hi)
    except RuntimeError as e: raise HTTPException(409, str(e))
    except KeyError as e: raise HTTPException(404, str(e))

# VI Pramana — verify a proof
@app.post("/proof/verify")
def verify(subject: str = Body(...), commitment: int = Body(...), x: int = Body(...), r: int = Body(...),
           x_team: str = Header(None)):
    s = team(x_team)
    try: return {"id": s.verify(subject, commitment, x, r)}
    except ValueError as e: raise HTTPException(400, str(e))

# IX Sakshi — audit ledger
@app.get("/audit")
def audit(x_team: str = Header(None)):
    return {"ledger": team(x_team).audit}

# X Rajakosha — vault release (composed)
@app.post("/vault/release")
def release(id: str = Body(..., embed=True), x_team: str = Header(None)):
    s = team(x_team)
    try: return s.vault_release(id)
    except PermissionError as e: raise HTTPException(403, str(e))
