# A02 — Gurukul: The Silent Instruction

*In the gurukul of Ayodhya the young princes are taught a mantra that is never spoken.
The teacher sets it upon a strange instrument — the VAC, the voice — and the student must
learn to sound it without a single syllable being named aloud. The instrument does not read
its notation the way any other does: the meaning of a stroke changes with the mood it is
played in, and the right mood is chosen by the tuning, by the bell, by the moment. Learn the
instrument. Then recite the silent instruction, and the gurukul's gate will open.*

## What you are given
- `firmware.rom` — the gurukul's firmware for the VAC processor.
- `vac_emu` — the VAC emulator (a stripped native binary). It runs the firmware on an
  activation mantra you provide and reports whether the gate opened.

```
./vac_emu firmware.rom <b0> <b1> <b2> <b3> <b4> <b5> <b6> <b7>
```
Each `b` is one mantra syllable (a byte, given in decimal). It prints:
```
activated=<0|1>
deepa=<hex of the lamp output>
tag=<64 hex characters — the retirement-trace tag>
```

## Goal
Find the **eight-syllable activation mantra** that drives the machine to its **activated**
state, then recite it to the gurukul gate. The VAC is an original processor: its instruction
encoding is *state-dependent* (the same opcode byte means different things depending on the
machine's current mode), it uses banked memory, a bell-timer interrupt, memory-mapped
peripherals, and arithmetic that is not the arithmetic of ordinary machines. Nothing about
the real instruction set is written down for you — recover it.

## Submission
The gate is served over HTTP by the platform for your instance. Submit:
```
POST /gurukul/activate
{ "mantra": [b0, b1, b2, b3, b4, b5, b6, b7], "trace_tag": "<the 64-hex tag>" }
```
The gate opens — and the flag is released — only when your mantra **activates** the machine
**and** the trace tag you submit matches the one the true machine emits. A correct mantra
without the correct trace tag is not enough: you must have actually sounded it on the real
instrument. There is no flag anywhere in the firmware or the emulator; it lives only behind
the gate.
