"""embassy-portal — session + identity. A player always acts as the envoy Angada; the sovereign, herald,
chamberlain and clerk are server-side workflow actors (no login for them -> no admin to compromise)."""
from fastapi import APIRouter, Depends
from .store import create_session
from .deps import ctx

router = APIRouter(prefix="/portal", tags=["embassy-portal"])

@router.post("/session")
def open_session():
    s = create_session()
    # the envoy's credential for this isolated sandbox
    return {"session_id": s.id, "login_as": "angada", "token": s.tokens["angada"],
            "note": "send X-Session and Authorization: Bearer <token> on every request"}

@router.get("/whoami")
def whoami(c=Depends(ctx)):
    s, user = c
    return {"user": user, "session": s.id}
