#!/usr/bin/env python3
"""Minimal DASHA client. Usage: set BASE; call the helpers. (Does not contain any solution.)"""
import sys, httpx
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000"
c = httpx.Client(base_url=BASE, timeout=30)
team = c.post("/gate/session").json()["team"]; H = {"X-Team": team}
def post(path, **body): return c.post(path, json=body or None, headers=H).json()
def get(path): return c.get(path, headers=H).json()
if __name__ == "__main__":
    print("team:", team)
    print("params:", get("/proof/params"))
    print("authorize:", post("/identity/authorize", subject="angada", amount=5))
    print("audit:", get("/audit"))
