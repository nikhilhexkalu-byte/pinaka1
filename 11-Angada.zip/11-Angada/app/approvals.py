"""approval-engine — the chamberlain reviews submitted revisions. Review is asynchronous: tasks queue and
are processed on an explicit tick (deterministic ordering, no production scheduling). Each approval records
the metadata snapshot read at review time."""
from fastapi import APIRouter, Depends, HTTPException, Body
from .deps import ctx, can_edit
from .store import new_id, resolve

router = APIRouter(prefix="/approvals", tags=["approval-engine"])

@router.post("")
def submit(doc_id: str = Body(...), rev_id: str = Body(...), c=Depends(ctx)):
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc: raise HTTPException(404, "no such document")
    if not can_edit(s, user, doc): raise HTTPException(403, "cannot submit this document")
    if rev_id not in doc["revisions"]: raise HTTPException(404, "no such revision")
    s.queue.append({"doc_id": doc_id, "rev_id": rev_id, "submitter": user})
    return {"queued": True, "position": len(s.queue)}

@router.post("/tick")
def tick(c=Depends(ctx)):
    s, user = c
    processed = []
    for task in s.queue:
        eff = resolve(s, task["doc_id"], task["rev_id"])          # metadata read at review time
        cls = eff["classification"] if eff else "normal"
        verdict = "approved" if cls == "normal" else "rejected"   # chamberlain clears only normal matter
        a = {"id": new_id("appr"), "doc_id": task["doc_id"], "rev_id": task["rev_id"],
             "approver": "chamberlain", "verdict": verdict,
             "clearance": "normal" if verdict == "approved" else None,
             "snapshot": {"classification": cls, "subject": eff["subject"] if eff else None}}
        s.approvals[a["id"]] = a
        processed.append({"doc_id": a["doc_id"], "rev_id": a["rev_id"], "verdict": verdict})
    s.queue = []
    return {"processed": processed}

@router.get("")
def mine(c=Depends(ctx)):
    s, user = c
    return [a for a in s.approvals.values() if s.documents.get(a["doc_id"], {}).get("owner") == user]
