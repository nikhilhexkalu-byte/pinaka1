# A05 — Tataka Vana: The Corrupted Forest

*Vishwamitra leads Rama and Lakshmana out of Siddhashrama and into Tataka's wood — a forest
so cursed that even its own records have rotted. For years the forest wardens kept a
telemetry network: every clearing, every trail between them, and the measured cost of walking
each trail, logged by a ring of recording stations. Then the corruption came. The ledgers were
torn, half-written transactions abandoned, whole stretches overwritten, and the stations' water-clocks
fell out of step with one another. Yet the sages insist a single safe passage still runs from
the ashram gate to Tataka's lair — one route, uniquely consistent with what the forest truly
recorded, if only it can be read back out of the wreckage.*

## What you are given

Three binary artifacts recovered from the forest-warden network (all custom, undocumented
formats — no schema is published):

| File | What it is |
|---|---|
| `forest.store` | A checkpoint of the trail map: the clearings and a baseline set of trails, each with a recorded traversal measurement. |
| `forest.wal`   | The warden's running log of trail changes made *after* the checkpoint. It is damaged: some records are torn, some transactions were never completed, and parts were overwritten. |
| `beacons.bin`  | The stations' shared-beacon log, from the watch-fires every station observed together. |

Nothing in these files is random filler — the whole corpus is one internally consistent
recording of one forest. The flag is **not** present in any file.

## Your goal

Recover the **single consistent route** — the lowest-total-cost passage from the entry
clearing (`source`) to Tataka's Lair (`target`) — that the forest's own records, read
correctly, uniquely determine. Present it, with the key facts you recovered along the way,
to Vishwamitra's seal (the validator) for your instance. The seal checks your answer against
the forest's true history server-side and, only on an exact match, returns the flag. There is
exactly one route that passes; guessing will not find it.

## Submission

`POST /vana/passage` with a JSON body:

```json
{
  "route": [source_id, ..., target_id],
  "route_cost": [numerator, denominator],
  "committed_edge_count": <integer>,
  "committed_graph_digest": "<sha256 hex>",
  "calibration": { "<station_id>": [alpha_num, alpha_den, beta_num, beta_den], ... }
}
```

- **route** — the ordered list of clearing ids from `source` to `target`.
- **route_cost** — the route's exact total traversal cost, as a reduced fraction `[numerator, denominator]`.
- **committed_edge_count** — how many trails are in the trail map you recovered.
- **committed_graph_digest** — a fingerprint of that recovered trail map: for every trail,
  the string `edge_id:src>dst:cost_num/cost_den` (cost as its exact reduced fraction), sorted
  ascending by `edge_id`, joined with `;`, hashed with SHA-256 (hex).
- **calibration** — the per-station clock model you recovered: for each station, its clock's
  slope and offset relative to the reference station, each as a reduced `[numerator, denominator]`.

All fields must be exactly right together. A route that looks plausible but rests on records
the forest never truly committed — or on uncorrected measurements — will be refused.
