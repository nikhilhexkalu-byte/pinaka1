"""document-versioning — documents, revisions, revision history, and two court workflow transitions
(tabling a registered document into a session, and ratifying a finalized reply into a document)."""
from fastapi import APIRouter, Depends, HTTPException, Body
from .deps import ctx, can_edit
from .store import new_id, resolve, user_cleared_for, has_restricted_clearance

router = APIRouter(prefix="/documents", tags=["document-versioning"])

@router.post("")
def create(subject: str = Body("ravana"), content: str = Body("Greetings from Rama's envoy."), c=Depends(ctx)):
    s, user = c
    did = new_id("doc"); rid = "rev1"
    s.documents[did] = {"id": did, "owner": user, "status": "draft", "subject": subject,
                        "current_rev": rid,
                        "revisions": {rid: {"content": content, "classification": "normal",
                                            "subject": subject, "author": user, "finalized": True}}}
    s.registry.add(did)                              # embassy documents are entered in the court registry
    return {"doc_id": did, "current_rev": rid}

@router.get("")
def registry(c=Depends(ctx)):
    """the court registry: every registered document's metadata (contents are not listed here)."""
    s, user = c
    out = []
    for did in sorted(s.registry):
        doc = s.documents[did]
        eff = resolve(s, did, doc["current_rev"])
        out.append({"doc_id": did, "owner": doc["owner"], "status": doc["status"],
                    "subject": doc["subject"], "current_rev": doc["current_rev"],
                    "classification": eff["classification"] if eff else "normal"})
    return out

@router.post("/{doc_id}/revisions")
def add_revision(doc_id: str, content: str = Body(...), classification: str = Body("normal"),
                 subject: str = Body(None), c=Depends(ctx)):
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc: raise HTTPException(404, "no such document")
    if not can_edit(s, user, doc): raise HTTPException(403, "no edit rights on this document")
    if classification == "restricted" and not has_restricted_clearance(s, user):
        raise HTTPException(403, "restricted classification requires court clearance")
    rid = new_id("rev")
    doc["revisions"][rid] = {"content": content, "classification": classification,
                             "subject": subject or doc["subject"], "author": user, "finalized": True}
    doc["current_rev"] = rid
    return {"doc_id": doc_id, "rev_id": rid}

@router.get("/{doc_id}")
def get_doc(doc_id: str, c=Depends(ctx)):
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc: raise HTTPException(404, "no such document")
    revs = {}
    for rid, r in doc["revisions"].items():
        eff = resolve(s, doc_id, rid)
        view = {"classification": eff["classification"], "subject": eff["subject"],
                "author": r.get("author"), "ref": r.get("ref")}
        # restricted content is only shown to those cleared for the SOURCE document (live check).
        if eff["classification"] == "restricted" and not user_cleared_for(s, user, eff["source"][0]):
            view["content"] = None; view["redacted"] = True
        else:
            view["content"] = eff["content"]
        revs[rid] = view
    return {"id": doc_id, "owner": doc["owner"], "status": doc["status"], "subject": doc["subject"],
            "current_rev": doc["current_rev"], "registered": doc_id in s.registry, "revisions": revs}

@router.post("/{doc_id}/table")
def table(doc_id: str, court_id: str = Body(..., embed=True), c=Depends(ctx)):
    s, user = c
    if doc_id not in s.registry: raise HTTPException(404, "document is not in the court registry")
    court = s.courts.get(court_id)
    if not court: raise HTTPException(404, "no such court session")
    if user not in court["participants"]: raise HTTPException(403, "not a participant of this session")
    if doc_id not in court["tabled"]:
        court["tabled"].append(doc_id)
    return {"court_id": court_id, "tabled": court["tabled"]}

@router.post("/{doc_id}/ratify")
def ratify(doc_id: str, source_doc_id: str = Body(...), source_rev_id: str = Body(...),
           court_id: str = Body(...), c=Depends(ctx)):
    """ratify a finalized reply (source_rev) into this document as its new current revision."""
    s, user = c
    doc = s.documents.get(doc_id)
    if not doc: raise HTTPException(404, "no such document")
    if not can_edit(s, user, doc): raise HTTPException(403, "no edit rights on this document")
    court = s.courts.get(court_id)
    if not court or user not in court["participants"]:
        raise HTTPException(403, "ratification must occur in a session you participate in")
    if doc_id not in court["tabled"] or source_doc_id not in court["tabled"]:
        raise HTTPException(409, "both documents must be tabled in the session")
    src = s.documents.get(source_doc_id)
    srev = src["revisions"].get(source_rev_id) if src else None
    if not srev or not srev.get("finalized"):
        raise HTTPException(409, "source revision is not a finalized reply")
    eff = resolve(s, source_doc_id, source_rev_id)
    rid = new_id("rev")
    doc["revisions"][rid] = {"ref": [source_doc_id, source_rev_id], "author": user, "finalized": True}
    doc["current_rev"] = rid
    doc["subject"] = eff["subject"]                   # the effective subject follows the ratified reply
    return {"doc_id": doc_id, "rev_id": rid, "subject": doc["subject"]}
