"""Pramana cryptographic primitives — binding Pedersen commitment in a DLP-hard prime-order subgroup.
(Lifted verbatim from the proven Phase-1 harness so the service and the harness agree bit-for-bit.)"""
import hashlib
P = int("0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74"
        "020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437"
        "4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
        "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05"
        "98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB"
        "9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
        "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718"
        "3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF", 16)
Q = (P - 1) // 2
G = 2
H = pow(G, int.from_bytes(hashlib.sha256(b"ravana-dasha-pedersen-h").digest(), "big") % Q, P)
def commit(x, r): return (pow(G, x % Q, P) * pow(H, r % Q, P)) % P
def hid(subject, a_norm): return hashlib.sha256(f"{subject}|{a_norm}".encode()).hexdigest()
