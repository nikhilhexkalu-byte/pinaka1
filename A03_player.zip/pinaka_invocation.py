#!/usr/bin/env python3
r"""PINAKA A03 "Vishvamitra -- The Broken Invocation" -- PUBLIC invocation primitive.

This is the exact client-side protocol module the Celestial Armory ships. It contains NO
secrets and NO witnesses: only the public group arithmetic, the Fiat-Shamir challenge the
armory uses, and the verifier. Load the group parameters and the weapon registry from the
JSON instance files that accompany this module (params.json, instance.json).

PROTOCOL  (Chaum-Pedersen equality-of-discrete-logs, non-interactive via Fiat-Shamir)
-------------------------------------------------------------------------------------
A STATEMENT is a boon tuple (A, B). It is TRUE iff there is a single witness w with
    A = g^w (mod p)   and   B = h^w (mod p).
A proof is (t1, t2, s). The armory accepts it for statement (A, B) iff
    g^s == t1 * A^c (mod p)   AND   h^s == t2 * B^c (mod p),
where c is the Fiat-Shamir challenge below.
"""
import json, os, hashlib

_HERE = os.path.dirname(os.path.abspath(__file__))


def load_params(path=None):
    with open(path or os.path.join(_HERE, "params.json")) as f:
        return json.load(f)


def load_instance(path=None):
    with open(path or os.path.join(_HERE, "instance.json")) as f:
        return json.load(f)


# ---- the Fiat-Shamir challenge the armory uses to seal an invocation --------------------
#
# NOTE for researchers: the challenge is computed over the commitments (t1, t2) ALONE.
# It is the binding syllable of the invocation -- study carefully what it does and does not
# fold into the hash.
def fiat_shamir_challenge(t1, t2, q):
    m = hashlib.sha256(b"PINAKA-A03-FS")
    m.update(b"|t1|"); m.update(str(t1).encode())
    m.update(b"|t2|"); m.update(str(t2).encode())
    return int(m.hexdigest(), 16) % q


def verify(params, A, B, proof):
    """Verify a Chaum-Pedersen proof (t1,t2,s) for boon tuple (A,B). Returns bool."""
    p, g, h, q = params["p"], params["g"], params["h"], params["q"]
    t1, t2, s = int(proof["t1"]), int(proof["t2"]), int(proof["s"])
    A, B = int(A), int(B)
    c = fiat_shamir_challenge(t1, t2, q)
    eq1 = pow(g, s, p) == (t1 * pow(A, c, p)) % p
    eq2 = pow(h, s, p) == (t2 * pow(B, c, p)) % p
    return eq1 and eq2


def prove(params, A, B, w):
    """Honest prover. REQUIRES the witness w such that A=g^w and B=h^w (mod p).
    Provided so the protocol is fully specified; players do not hold the forbidden witness."""
    import secrets
    p, g, h, q = params["p"], params["g"], params["h"], params["q"]
    r = secrets.randbelow(q - 1) + 1
    t1, t2 = pow(g, r, p), pow(h, r, p)
    c = fiat_shamir_challenge(t1, t2, q)
    s = (r + c * w) % q
    return {"t1": t1, "t2": t2, "s": s}


if __name__ == "__main__":
    # self-check: the shipped leaked grant verifies for its permitted boon tuple.
    params = load_params()
    inst = load_instance()
    w = inst["leaked_grant"]["weapon"]
    tup = inst["weapons"][w]["boon_tuple"]
    ok = verify(params, tup["A"], tup["B"], inst["leaked_grant"]["proof"])
    print(f"leaked grant for {w!r} verifies: {ok}")
