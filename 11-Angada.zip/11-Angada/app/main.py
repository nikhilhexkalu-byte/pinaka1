"""Angada's Embassy — the royal court document & approval system (five services)."""
from fastapi import FastAPI
from . import portal, delegation, documents, approvals, dispatch

app = FastAPI(title="Angada's Embassy", version="1.0",
              description="Ravana's court: documents, delegation, approvals, dispatch.")
for m in (portal, delegation, documents, approvals, dispatch):
    app.include_router(m.router)

@app.get("/")
def root():
    return {"name": "Angada's Embassy", "services": ["embassy-portal", "delegation-authority",
            "document-versioning", "approval-engine", "dispatch-service"],
            "start": "POST /portal/session"}

@app.get("/health")
def health():
    return {"ok": True}
