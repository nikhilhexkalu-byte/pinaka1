#!/usr/bin/env python3
"""Himalaya Botanical Survey — local research portal (catalog search).

Searches the lab's metadata catalog (archive_catalog.json) across the three storage nodes. This is
only the portal's VISIBLE metadata: it is stale/inconsistent across nodes and is NOT authoritative —
it holds no spectra, journals, or calibration. Use it to navigate; reconstruct the truth from the
raw node snapshots + journals.

Usage:
  python3 research_cli.py list                       # all specimen ids seen in any node
  python3 research_cli.py show <specimen_id>          # per-node view of one specimen
  python3 research_cli.py search [--species S] [--site N] [--instr I] [--gen G]
  python3 research_cli.py conflicts                   # specimens whose metadata DIFFERS across nodes
"""
import json, sys, os, argparse
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
CAT = json.load(open(os.path.join(HERE, "archive_catalog.json")))["nodes"]

def by_id():
    d = defaultdict(dict)
    for node, rows in CAT.items():
        for r in rows:
            d[r["specimen_id"]][node] = r
    return d

def fmt(r):
    return "species=0x%04X site=%d instr=%d gen=%d" % (r["species_code"], r["site_id"], r["instrument_id"], r["gen"])

def cmd_list(_):
    ids = sorted(by_id())
    print("%d specimens visible across nodes:" % len(ids))
    print(" ".join(str(i) for i in ids))

def cmd_show(a):
    d = by_id().get(a.specimen_id)
    if not d: print("not visible in any node"); return
    print("specimen %d:" % a.specimen_id)
    for node in "ABC":
        print("  node_%s: %s" % (node, fmt(d[node]) if node in d else "(absent)"))

def cmd_search(a):
    hits = []
    for sid, d in by_id().items():
        for node, r in d.items():
            if a.species is not None and r["species_code"] != int(a.species, 0): continue
            if a.site   is not None and r["site_id"] != a.site: continue
            if a.instr  is not None and r["instrument_id"] != a.instr: continue
            if a.gen    is not None and r["gen"] != a.gen: continue
            hits.append((sid, node, r));
    for sid, node, r in sorted(hits):
        print("id=%d node_%s %s" % (sid, node, fmt(r)))
    print("-- %d match(es)" % len(hits))

def cmd_conflicts(_):
    print("specimens whose VISIBLE metadata differs across nodes (stale/superseded candidates):")
    for sid, d in sorted(by_id().items()):
        views = {node: (r["species_code"], r["gen"]) for node, r in d.items()}
        if len(set(views.values())) > 1:
            print("  id=%d  " % sid + "  ".join("%s:(sp=0x%04X,gen=%d)" % (n, v[0], v[1]) for n, v in views.items()))

def main():
    p = argparse.ArgumentParser(description="Himalaya Botanical Survey — catalog search")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list").set_defaults(fn=cmd_list)
    s = sub.add_parser("show"); s.add_argument("specimen_id", type=int); s.set_defaults(fn=cmd_show)
    s = sub.add_parser("search")
    s.add_argument("--species"); s.add_argument("--site", type=int); s.add_argument("--instr", type=int)
    s.add_argument("--gen", type=int); s.set_defaults(fn=cmd_search)
    sub.add_parser("conflicts").set_defaults(fn=cmd_conflicts)
    a = p.parse_args(); a.fn(a)

if __name__ == "__main__":
    main()
